package com.informatika.databarang

class SplashScreen {
}